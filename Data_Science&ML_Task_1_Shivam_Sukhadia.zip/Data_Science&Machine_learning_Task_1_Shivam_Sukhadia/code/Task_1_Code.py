import pandas as pd
from pandas import json_normalize

# JSON data
data = {
    "users": [
        {
            "id": 101,
            "name": "Rohan Desai",
            "info": {
                "email": "rohan@example.com",
                "address": {
                    "city": "Vadodara",
                    "pincode": "390018"
                }
            }
        },
        {
            "id": 102,
            "name": "Rajesh Patel",
            "info": {
                "email": "raj123@example.com",
                "address": {
                    "city": "Vadodara",
                    "pincode": "390017"
                }
            }
        },
        {
             "id":103,
            "name": "Sakhi Shah",
            "info": {
                "email": "sakhi@example.com",
                "address": {
                    "city": "Ahmedabad",
                    "pincode": "380017"
                }
            }
        },
         {
             "id": 104,
            "name": "Nirav Modi",
            "info": {
                "email": "nirav@example.com",
                "address": {
                    "city": "Surat",
                    "pincode": "394440"
                }
            }
        },
          {
             "id": 105,
            "name": "Aakash Patel",
            "info": {
                "email": "aakash@example.com",
                "address": {
                    "city": "Vadodara",
                    "pincode": "390001"
                }
            }
        },
         
    ]
}

# Flatten the nested JSON structure
df = json_normalize(
    data['users'], 
    sep='_',  
    record_path=None, 
    meta=['id', 'name', ['info', 'email'], ['info', 'address', 'city'], ['info', 'address', 'zipcode']],
    errors='ignore'
)
df.columns = ['id', 'name', 'email', 'city', 'zipcode']
print(df)
